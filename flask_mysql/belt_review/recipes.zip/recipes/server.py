from recipes_app.controllers import users, recipes
from recipes_app import app



if __name__=="__main__":
    app.run(debug=True) 